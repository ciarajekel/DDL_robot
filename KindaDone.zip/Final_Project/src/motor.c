/*
 * motor.c
 *
 *  Created on: Apr 23, 2019
 *      Author: Ciara
 */

#include "motor.h"
#include "dma.h"
#include "letimer0.h"
#include "leuart.h"
#include "adc.h"

uint8_t hold_flag = 0;

void motor_gpio_init(){

	GPIO_DriveStrengthSet(MOTOR_PORT, gpioDriveStrengthWeakAlternateWeak);
	GPIO_PinModeSet(MOTOR_PORT, RIGHT_MOTOR_DIR, gpioModePushPull, MOTOR_DEFAULT);
	GPIO_PinModeSet(MOTOR_PORT, RIGHT_MOTOR_PWM, gpioModePushPull, MOTOR_DEFAULT);
	GPIO_PinModeSet(MOTOR_PORT, LEFT_MOTOR_DIR, gpioModePushPull, MOTOR_DEFAULT);
	GPIO_PinModeSet(MOTOR_PORT, LEFT_MOTOR_PWM, gpioModePushPull, MOTOR_DEFAULT);

}
//robot forward
void robot_forward(float time){
	dma_TX_init("Moving Forward\n",14);


	TIMER0->CMD = TIMER_CMD_START;
	GPIO_PinOutClear(MOTOR_PORT, RIGHT_MOTOR_DIR);
	GPIO_PinOutClear(MOTOR_PORT, LEFT_MOTOR_DIR);
	TIMER0->CC[0].CCV=MOTOR_SPEED;		//right //use to change value  < CC Channel Buffer Register
	TIMER0->CC[1].CCV=MOTOR_SPEED;		//left //use to change value  < CC Channel Buffer Register

	/* Initialize LETIMER0 according to values in *****MAIN.H*****/
	letimer0_single_init(time);
}

//motor off
void robot_stop(void){

	TIMER0->CMD = TIMER_CMD_STOP;
	TIMER0->CC[0].CCV=0;	//right	//use to change value  < CC Channel Buffer Register
	TIMER0->CC[1].CCV=0;	//left	//use to change value  < CC Channel Buffer Register

//	GPIO_PinOutClear(MOTOR_PORT, RIGHT_MOTOR_PWM);
	GPIO_PinOutClear(MOTOR_PORT, RIGHT_MOTOR_DIR);
//	GPIO_PinOutClear(MOTOR_PORT, LEFT_MOTOR_PWM);
	GPIO_PinOutClear(MOTOR_PORT, LEFT_MOTOR_DIR);
}
//robot backward
void robot_backward(float time){
	dma_TX_init("Moving Backwards\n",16);

	TIMER0->CMD = TIMER_CMD_START;
	GPIO_PinOutSet(MOTOR_PORT, RIGHT_MOTOR_DIR);
	GPIO_PinOutSet(MOTOR_PORT, LEFT_MOTOR_DIR);
	TIMER0->CC[0].CCV=MOTOR_SPEED;		//right //use to change value  < CC Channel Buffer Register
	TIMER0->CC[1].CCV=MOTOR_SPEED;		//left //use to change value  < CC Channel Buffer Register

	/* Initialize LETIMER0 according to values in *****MAIN.H*****/
	letimer0_single_init(time);
}
//robot right
void robot_right(void){
	dma_TX_init("Turning right\n",14);

	TIMER0->CMD = TIMER_CMD_START;
	GPIO_PinOutSet(MOTOR_PORT, RIGHT_MOTOR_DIR);
	GPIO_PinOutClear(MOTOR_PORT, LEFT_MOTOR_DIR);
	TIMER0->CC[0].CCV=MOTOR_SPEED;		//right //use to change value  < CC Channel Buffer Register
	TIMER0->CC[1].CCV=MOTOR_SPEED;		//left //use to change value  < CC Channel Buffer Register

	letimer0_single_init(TURNRIGHT_TIME);
}
//robot left
void robot_left(void){
	dma_TX_init("Turning Left\n",13);

	TIMER0->CMD = TIMER_CMD_START;
	GPIO_PinOutClear(MOTOR_PORT, RIGHT_MOTOR_DIR);
	GPIO_PinOutSet(MOTOR_PORT, LEFT_MOTOR_DIR);
	TIMER0->CC[0].CCV=MOTOR_SPEED;		//right //use to change value  < CC Channel Buffer Register
	TIMER0->CC[1].CCV=MOTOR_SPEED;		//left //use to change value  < CC Channel Buffer Register

	letimer0_single_init(TURNLEFT_TIME);
}

void controlled_forward(float avg){
	TIMER0->CMD = TIMER_CMD_START;
	GPIO_PinOutClear(MOTOR_PORT, RIGHT_MOTOR_DIR);
	GPIO_PinOutClear(MOTOR_PORT, LEFT_MOTOR_DIR);
	TIMER0->CC[0].CCV=MOTOR_SPEED/2;		//right //use to change value  < CC Channel Buffer Register
	TIMER0->CC[1].CCV=MOTOR_SPEED/2;		//left //use to change value  < CC Channel Buffer Register

	float dist_out = get_distance();
	while(dist_out > avg){
		dist_out = get_distance();
	}
	robot_stop();
}

void controlled_backward(float avg){
	TIMER0->CMD = TIMER_CMD_START;
	GPIO_PinOutSet(MOTOR_PORT, RIGHT_MOTOR_DIR);
	GPIO_PinOutSet(MOTOR_PORT, LEFT_MOTOR_DIR);
	TIMER0->CC[0].CCV=MOTOR_SPEED/2;		//right //use to change value  < CC Channel Buffer Register
	TIMER0->CC[1].CCV=MOTOR_SPEED/2;		//left //use to change value  < CC Channel Buffer Register

	float dist_out = get_distance();
	while(dist_out < avg){
		dist_out = get_distance();
	}
	robot_stop();
}


//This function tries to center the robot forwards and backwards.
//It uses the ADC to read the distance in front and behind it, and moves accordingly
void robot_center(){

	//Get distance in front:
	float dist_front = get_distance();

	//Rotate 180 degrees
	hold_flag = 1;
	robot_right();
	while(hold_flag);

	Sleep_Block_Mode(EM2_DEEPSLEEP);

	hold_flag = 1;
	robot_right();
	while(hold_flag);

	float dist_back = get_distance();

	//Get the difference between the two distances
	float dif =  dist_back - dist_front;

	float avg = (dist_back + dist_front)/2;

	if(dist_front > 36 || dist_back > 36){
		dma_TX_init("Wall is too far\n",16);
	}
	//We move about 14 inches per forward step.  Use this to determine how far to move forward.
	//We need to halve that distance in order to properly center everything
	else if(dif > 0.1){
		//Sleep_Block_Mode(EM2_DEEPSLEEP);
		//float onTime = (dif*2/(DISTANCE_TRAVELED/2));
		//robot_forward(onTime);
		dma_TX_init("Move FWD\n",9);
		controlled_forward(avg);
	}
	//Otherwise we want to move backwards
	else if(dif < -0.1){
		//Sleep_Block_Mode(EM2_DEEPSLEEP);
//		float onTime = (-dif*2/(DISTANCE_TRAVELED));
//		robot_backward(onTime);
		dma_TX_init("Move BWD\n",9);
		controlled_backward(avg);
	}
	else{
		dma_TX_init("Close Enough\n",13);
	}

}

//This function will measure the distance to the left wall.  It rotates to the left measures and rotates to the right
double get_Left(){
	//Rotate 90 degrees
	hold_flag = 1;
	robot_left();
	while(hold_flag);

	//Measure the distance
	float dist = get_distance();

	//Rotate 90 degrees
	hold_flag = 1;
	robot_right();
	while(hold_flag);

	return dist;
}

//This function will measure the distance to the right wall.  It rotates to the left measures and rotates to the right
double get_Right(){
	//Rotate 90 degrees
	hold_flag = 1;
	robot_right();
	while(hold_flag);

	//Measure the distance
	float dist = get_distance();

	//Rotate 90 degrees
	hold_flag = 1;
	robot_left();
	while(hold_flag);

	return dist;
}

