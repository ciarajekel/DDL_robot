#include "em_timer.h"

void timer0_init(void);
