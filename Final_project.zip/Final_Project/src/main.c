/***************************************************************************//**
 * @file
 * @brief Simple LED Blink Demo for SLSTK3402A
 *******************************************************************************
 * # License
 * <b>Copyright 2018 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#include "em_device.h"
#include "em_core.h"
#include "em_chip.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "bsp.h"
#include "main.h"
#include "gpio.h"
#include "cmu.h"
#include "letimer0.h"
#include "sleep.h"
#include "leuart.h"
#include "dma.h"
#include "msg.h"

#include "adc.h"
#include "timer.h"
#include "motor.h"

extern uint8_t message_flag;
extern uint8_t msg_in [RX_BUFFER_SIZE];


int main(void)
{
  EMU_DCDCInit_TypeDef dcdcInit = EMU_DCDCINIT_DEFAULT;
  CMU_HFXOInit_TypeDef hfxoInit = CMU_HFXOINIT_DEFAULT;

  /* Chip errata */
  CHIP_Init();

  /* Init DCDC regulator and HFXO with kit specific parameters */
  EMU_DCDCInit(&dcdcInit);
  CMU_HFXOInit(&hfxoInit);

  //Initialize DCDC in low-noise mode
  EMU_EM23Init_TypeDef em23Init = EMU_EM23INIT_DEFAULT;
  em23Init.vScaleEM23Voltage = emuVScaleEM23_LowPower;
  EMU_EM23Init(&em23Init);

  /* Switch HFCLK to HFXO and disable HFRCO */
  CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFXO);
  CMU_OscillatorEnable(cmuOsc_HFRCO, false, false);

  /* Initialize clocks */
  cmu_init();

  /* Initialize GPIO */
  gpio_init();

  //Global Interrupt Enable
  CORE_ATOMIC_IRQ_ENABLE();

  //BLOCK EM ACCORDING TO THE DEFINED VALUE IN ******MAIN.h*******
  Sleep_Block_Mode(LOWEST_ENERGY_MODE+1);

  //Initialize the LEUART0 peripheral
  leuart_init();

  //Initialize the ldma generally and enable reception
  dma_init();

  //Initialize the Hash table used for decoding
  build_hash();
#ifdef DEBUG
  //If the debug flag is defined,
  test_dec_msg();
#endif


  //Malloc one large transmission string to communicate out with
  char * transm = (char *) malloc(sizeof(uint8_t)*100);

  timer0_init();
  motor_gpio_init();
  adc_init();

//  Sleep_Block_Mode(2);
//  while(1){
////	  ADC0->CMD = ADC_CMD_SINGLESTART;
////	  robot_forward(FORWARD_TIME);
//	  Enter_Sleep();
//	  for(int i = 0; i < 100000; i ++);
//  }

  //Write the new name to the bluetooth
  //Add a delay loop to make sure everything is set up properly
//  for(int i = 0; i < 100000;i++);
//  leuart_write_string("AT+NAMEavan\n\r",13);

  //NOTE WRITE_FLAG IS SET IN LETIMER0 SO THE REGISTERIS CONFIGURED EVERY 3.5 SECONDS
  while (1){

	  if(message_flag){
		  //Our message is defined in the msg_in, check to see if it is a known command
		  int32_t dec = (decode_msg(msg_in));

		  //if(dec < 0){
			//  dma_TX_init("That was not a known command\n",29);
		  //}

		  float dist;
  		  char dist_s[5];
  		  transm[0] = '\0';

  		  Sleep_Block_Mode(EM2_DEEPSLEEP);

		  switch(dec){
		  	  case Move_Forward:
		  	      //Call the move forward function to go forward
		  		  robot_forward(FORWARD_TIME);


		  		  break;
		  	  case  Move_Backward:
		  		  //Call the move forward function to go forward
		  		  robot_backward(BACKWARD_TIME);

		  		  break;
		  	  case Stop:
		  		  //Stop whatever command is currently running
		  		  dma_TX_init("Stopping\n",8);
		  		  robot_stop();
		  		  Sleep_UnBlock_Mode(EM2_DEEPSLEEP);
		  		  break;
		  	  case Turn_Left:
		  		  //Rotate to the left
		  		  robot_left();

		  		  break;
		  	  case Turn_Right:

		  		  //Rotate to the right
		  		  robot_right();

		  		  break;
		  	  case Left_Distance:
		  		  //Find the distance to the left
		  		  dist = get_Left();
		  		  dist_f_2_a(dist_s, dist);

		  		  strcat(transm,"The left wall is ");
		  		  strcat(transm,dist_s);
		  		  strcat(transm,"in away\n");

		  		  dma_TX_init(transm,29);
		  		  start_rx();
		  		  break;
		  	  case Right_Distance:
		  		  //Find the distance to the right
		  		  dist = get_Right();
		  		  dist_f_2_a(dist_s, dist);

		  		  strcat(transm,"The right wall is ");
		  		  strcat(transm,dist_s);
		  		  strcat(transm,"in away\n");

		  		  dma_TX_init(transm,30);
		  		  start_rx();
		  		  break;
		  	  case Forward_Distance:
		  		  //Find the distance to the right
		  		  dist = get_distance();
		  		  dist_f_2_a(dist_s, dist);

		  		  strcat(transm,"The front wall is ");
		  		  strcat(transm,dist_s);
		  		  strcat(transm,"in away\n");

		  		  dma_TX_init(transm,30);
		  		  Sleep_UnBlock_Mode(EM2_DEEPSLEEP);
		  		  start_rx();
		  		  break;
		  	  case Center:
		  		  robot_center();

		  		  break;
		  	  case Solve:
		  		  dma_TX_init("Solving\n",8);

		  		  Sleep_UnBlock_Mode(EM2_DEEPSLEEP);
		  		  start_rx();
		  		  break;
		  	  default:
		  		  //The command was not recognized, tell that to the user
			  	  dma_TX_init("That was not a known command\n",29);
		  		  Sleep_UnBlock_Mode(EM2_DEEPSLEEP);
		  		  start_rx();
		  	  	  break;
		   }


		  message_flag = 0;
	  }
	  //If we aren't doing anything, just go to sleep
	  if((!message_flag))
		  Enter_Sleep();
  }
}
